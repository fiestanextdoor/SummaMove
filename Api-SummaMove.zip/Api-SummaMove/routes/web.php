<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OefeningController;

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
    Route::get('/dashboard/gebruikers', [DashboardController::class, 'gebruikers'])->name('dashboard.gebruikers');
    Route::get('/dashboard/prestaties', [DashboardController::class, 'prestaties'])->name('dashboard.prestaties');

    Route::prefix('dashboard')->name('dashboard.')->group(function () {
        Route::resource('oefeningen', OefeningController::class)->except('show');
    });
});
