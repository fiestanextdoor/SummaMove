<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Prestatie extends Model
{
    protected $fillable = ['gebruiker_id', 'oefening_id', 'datum', 'starttijd', 'eindtijd', 'aantal'];

    public function gebruiker(): BelongsTo
    {
        return $this->belongsTo(User::class, 'gebruiker_id');
    }

    public function oefening(): BelongsTo
    {
        return $this->belongsTo(Oefening::class);
    }
}
