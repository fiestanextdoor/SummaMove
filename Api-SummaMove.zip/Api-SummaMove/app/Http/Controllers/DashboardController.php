<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Oefening;
use App\Models\Prestatie;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard');
    }

    public function gebruikers()
    {
        $gebruikers = User::all();
        return view('gebruikers', compact('gebruikers'));
    }

    public function prestaties()
    {
        $prestaties = Prestatie::with(['gebruiker', 'oefening'])->get();
        return view('prestaties', compact('prestaties'));
    }
}
