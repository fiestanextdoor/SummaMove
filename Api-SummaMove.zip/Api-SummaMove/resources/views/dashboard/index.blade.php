@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <h1>Welkom op het dashboard!</h1>
    <p>Kies een optie in het menu hierboven om verder te gaan.</p>
@endsection
