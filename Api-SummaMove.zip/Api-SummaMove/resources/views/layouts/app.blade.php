<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') – SummaMove</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; }
        header { background: #333; color:#fff; display:flex; justify-content:space-between; align-items:center; padding:12px 20px; }
        header nav a { color:#fff; margin-right:20px; text-decoration:none; font-weight:bold; }
        header nav a:hover { text-decoration:underline; }
        header form button { background:#ff5555; border:none; color:#fff; padding:6px 12px; cursor:pointer; }
        header form button:hover { background:#cc4444; }
        main { max-width:900px; margin:20px auto; padding:0 20px; }
        .alert-success { background:#d4edda; border:1px solid #c3e6cb; color:#155724; padding:10px 15px; border-radius:4px; margin-bottom:15px; }
        .btn { background:#007bff; color:#fff; padding:6px 12px; text-decoration:none; border-radius:4px; font-size:14px; margin-right:5px; display:inline-block; }
        .btn:hover { background:#0056b3; }
        .btn-danger { background:#dc3545; }
        .btn-danger:hover { background:#a71d2a; }
        table { width:100%; border-collapse:collapse; margin-top:15px; background:#fff; }
        th, td { border:1px solid #ddd; padding:8px 12px; text-align:left; }
        th { background:#eee; }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="{{ route('dashboard.index') }}">Dashboard</a>
            <a href="{{ route('dashboard.gebruikers') }}">Gebruikers</a>
            <a href="{{ route('dashboard.prestaties') }}">Prestaties</a>
            <a href="{{ route('dashboard.oefeningen.index') }}">Oefeningen</a>
        </nav>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit">Uitloggen</button>
        </form>
    </header>
    <main>
        @if(session('success'))
            <div class="alert-success">{{ session('success') }}</div>
        @endif
        @yield('content')
    </main>
</body>
</html>
